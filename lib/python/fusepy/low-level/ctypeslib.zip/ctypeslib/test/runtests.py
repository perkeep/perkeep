import sys
import ctypeslib.test

if __name__ == "__main__":
    sys.exit(ctypeslib.test.main(ctypeslib.test))
