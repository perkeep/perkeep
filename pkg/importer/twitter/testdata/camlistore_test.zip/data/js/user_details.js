var user_details =  {
  "screen_name" : "camlistore_test",
  "created_at" : "2016-05-03 05:18:36 +0000",
  "full_name" : "Camlistore Test",
  "id" : "727366726141239296"
}