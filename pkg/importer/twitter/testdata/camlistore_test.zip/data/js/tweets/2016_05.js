Grailbird.data.tweets_2016_05 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camlistore",
      "screen_name" : "Camlistore",
      "indices" : [ 44, 55 ],
      "id_str" : "314776085",
      "id" : 314776085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Ld5gT3wjyq",
      "expanded_url" : "https:\/\/github.com\/camlistore\/camlistore\/issues\/476",
      "display_url" : "github.com\/camlistore\/cam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727367542772133888",
  "text" : "&amp; &lt;&gt; . $ % ^ * &amp;&amp; \/\\\/\\()! @Camlistore camlistore. https:\/\/t.co\/Ld5gT3wjyq",
  "id" : 727367542772133888,
  "created_at" : "2016-05-03 05:21:50 +0000",
  "user" : {
    "name" : "Camlistore Test",
    "screen_name" : "camlistore_test",
    "protected" : false,
    "id_str" : "727366726141239296",
    "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_0_normal.png",
    "id" : 727366726141239296,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727366997390946304",
  "text" : "I am a test account. Beep boop.",
  "id" : 727366997390946304,
  "created_at" : "2016-05-03 05:19:40 +0000",
  "user" : {
    "name" : "Camlistore Test",
    "screen_name" : "camlistore_test",
    "protected" : false,
    "id_str" : "727366726141239296",
    "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_0_normal.png",
    "id" : 727366726141239296,
    "verified" : false
  }
} ]